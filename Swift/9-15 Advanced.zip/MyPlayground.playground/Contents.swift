//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var variable = 10
variable = 0
let constant = 10
// constant = 0 – Error because this is a constant and you can't reassign

for i in 0..<10 {
    // for 0 througn 9 (because less than 10) run this...
    // ...
}

func functionName(param1: String, param2: String) -> String {
    // Put what you want your function to do
    return "return value"
}

print(functionName(param1: "String", param2: "String"))
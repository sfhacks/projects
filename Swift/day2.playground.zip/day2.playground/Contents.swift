/*:
 # Swift Functions
 @amarjayr, @wchern
 
 **@sfhacks**
 
 Thursday, September 15, 2016
 
 
 ## First, Xcode 8
 
 - Supports new SDKs for iOS 10, macOS Sierra, watchOS 3, and tvOS 10
 - Compatible with macOS El Capitan and newer
 - Download from the [Mac App Store](https://itunes.apple.com/us/app/xcode/id497799835?mt=12) or [developer.apple.com/xcode](https://developer.apple.com/xcode)
 
 ## Function Signatures
*/
func multiply(x:Double, y:Double) -> Double {
    return x * y
}

let x = 5.5
let y = 6.0

multiply(x: x, y: y)


